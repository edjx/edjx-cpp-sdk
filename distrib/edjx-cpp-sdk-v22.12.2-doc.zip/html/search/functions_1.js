var searchData=
[
  ['basestream_0',['BaseStream',['../classedjx_1_1stream_1_1BaseStream.html#a21d6735a2101fd6fa76e2c4dfc466a2a',1,'edjx::stream::BaseStream::BaseStream()'],['../classedjx_1_1stream_1_1BaseStream.html#a471f8b6ba2dac941740b537b9e67e71b',1,'edjx::stream::BaseStream::BaseStream(uint32_t sd)']]]
];
