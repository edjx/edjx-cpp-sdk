var searchData=
[
  ['logger_2ehpp_0',['logger.hpp',['../logger_8hpp.html',1,'']]]
];
