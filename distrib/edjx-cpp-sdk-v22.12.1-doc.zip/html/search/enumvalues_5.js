var searchData=
[
  ['internalerror_0',['InternalError',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467a8462b58246e70e5c83e5b939a9332cb5',1,'edjx::error']]],
  ['invalidattributes_1',['InvalidAttributes',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467a06848e5749e7a27d67955095b252ef70',1,'edjx::error']]]
];
