var searchData=
[
  ['delete_0',['DELETE',['../namespaceedjx_1_1http.html#af8b6065e534538695e8525d5795377f2a32f68a60cef40faedbc6af20298c1a1e',1,'edjx::http']]],
  ['deletedbucketid_1',['DeletedBucketID',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467a322d985960d3c9949b4e332156b5942d',1,'edjx::error']]]
];
