var searchData=
[
  ['headers_0',['headers',['../structedjx_1_1fetch_1_1FetchResponse.html#a343b4c3f1219eef27b4ef7598fb304da',1,'edjx::fetch::FetchResponse::headers()'],['../structedjx_1_1fetch_1_1HttpFetch.html#ab96d14fa49cd0274a8f9f4717393269e',1,'edjx::fetch::HttpFetch::headers()'],['../structedjx_1_1request_1_1HttpRequest.html#ad1b5ebbdf341b4c6fc295adf129c930b',1,'edjx::request::HttpRequest::headers()'],['../structedjx_1_1response_1_1HttpResponse.html#a56f798fa73942df5a62261485f934a82',1,'edjx::response::HttpResponse::headers()'],['../structedjx_1_1storage_1_1StorageResponse.html#aaff4b43a33133b09b2f840edcd48c591',1,'edjx::storage::StorageResponse::headers()']]]
];
