var searchData=
[
  ['read_5fstream_0',['read_stream',['../structedjx_1_1fetch_1_1FetchResponse.html#a1932451213dfe25f8e6245db05d8ae3c',1,'edjx::fetch::FetchResponse::read_stream()'],['../structedjx_1_1storage_1_1StorageResponse.html#a872ebe5b0905ddc6cb3848d2dd75f939',1,'edjx::storage::StorageResponse::read_stream()']]]
];
