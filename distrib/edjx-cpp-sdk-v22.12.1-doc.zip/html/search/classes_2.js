var searchData=
[
  ['fetchresponse_0',['FetchResponse',['../structedjx_1_1fetch_1_1FetchResponse.html',1,'edjx::fetch']]],
  ['fetchresponsepending_1',['FetchResponsePending',['../structedjx_1_1fetch_1_1FetchResponsePending.html',1,'edjx::fetch']]],
  ['fileattributes_2',['FileAttributes',['../structedjx_1_1storage_1_1FileAttributes.html',1,'edjx::storage']]]
];
