var searchData=
[
  ['patch_0',['PATCH',['../namespaceedjx_1_1http.html#af8b6065e534538695e8525d5795377f2a63bc9a3997d66d835d9f3ec29451407d',1,'edjx::http']]],
  ['post_1',['POST',['../namespaceedjx_1_1http.html#af8b6065e534538695e8525d5795377f2aa02439ec229d8be0e74b0c1602392310',1,'edjx::http']]],
  ['put_2',['PUT',['../namespaceedjx_1_1http.html#af8b6065e534538695e8525d5795377f2a3e75383a5992a6d15fb81e872e46e256',1,'edjx::http']]]
];
