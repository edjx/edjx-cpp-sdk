var searchData=
[
  ['sd_0',['sd',['../structedjx_1_1fetch_1_1FetchResponsePending.html#ae08f59e25275589b9a8434b1b68da6d2',1,'edjx::fetch::FetchResponsePending::sd()'],['../structedjx_1_1storage_1_1StorageResponsePending.html#aa572295ef87e8a3e4ff8411f0ee8e861',1,'edjx::storage::StorageResponsePending::sd()'],['../classedjx_1_1stream_1_1BaseStream.html#a4b0cae1e4343dc0b1e5f49bc58550a0d',1,'edjx::stream::BaseStream::sd()']]],
  ['status_1',['status',['../structedjx_1_1fetch_1_1FetchResponse.html#a0c167f4c528c770e03ea8f1ca79a5177',1,'edjx::fetch::FetchResponse::status()'],['../structedjx_1_1response_1_1HttpResponse.html#a83f288d45beae1e8472d93fee5fd9965',1,'edjx::response::HttpResponse::status()']]]
];
