var searchData=
[
  ['missingattributes_0',['MissingAttributes',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467a3089f9458719751309bfb2087043c903',1,'edjx::error']]],
  ['missingbucketid_1',['MissingBucketID',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467afbebd324610ea566a394f59a640687fc',1,'edjx::error']]],
  ['missingfilename_2',['MissingFileName',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467a8555002378487dcb128933883a859e3a',1,'edjx::error']]]
];
