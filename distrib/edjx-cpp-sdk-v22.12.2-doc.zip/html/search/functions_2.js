var searchData=
[
  ['close_0',['close',['../classedjx_1_1stream_1_1BaseStream.html#a797fd63b322521c2421df65d2032400a',1,'edjx::stream::BaseStream']]]
];
