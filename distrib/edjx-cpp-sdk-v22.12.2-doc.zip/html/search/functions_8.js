var searchData=
[
  ['info_0',['info',['../namespaceedjx_1_1logger.html#aa69e17482cb87af2f8cffabc74b00267',1,'edjx::logger']]],
  ['is_5finitialized_1',['is_initialized',['../classedjx_1_1stream_1_1BaseStream.html#a4b9e1d5390a5c40e4efe306fa44fc959',1,'edjx::stream::BaseStream']]]
];
