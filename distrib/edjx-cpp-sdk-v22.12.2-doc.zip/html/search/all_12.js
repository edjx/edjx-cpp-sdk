var searchData=
[
  ['unauthorized_0',['UnAuthorized',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65ab2889fef041d52c0c3f04d6355e42a20',1,'edjx::error::UnAuthorized()'],['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467ab2889fef041d52c0c3f04d6355e42a20',1,'edjx::error::UnAuthorized()']]],
  ['unknown_1',['Unknown',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65a88183b946cc5f0e8c96b2e66e1c74a7e',1,'edjx::error::Unknown()'],['../namespaceedjx_1_1error.html#a0b0456030ab8f21099b6e255d0e15b07a88183b946cc5f0e8c96b2e66e1c74a7e',1,'edjx::error::Unknown()']]],
  ['unknownerror_2',['UnknownError',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326abfaef30f1c8011c5cefa38ae470fb7aa',1,'edjx::error']]],
  ['uri_3',['Uri',['../classedjx_1_1http_1_1Uri.html',1,'edjx::http']]],
  ['uri_4',['uri',['../structedjx_1_1fetch_1_1HttpFetch.html#ac5f50f127886a372444e4253d5776190',1,'edjx::fetch::HttpFetch::uri()'],['../structedjx_1_1request_1_1HttpRequest.html#a88d35be3ce1a737ea0c1722dfb8128d0',1,'edjx::request::HttpRequest::uri()']]],
  ['uri_5',['Uri',['../classedjx_1_1http_1_1Uri.html#a465f7c27d8fadb814a36014d8b48934d',1,'edjx::http::Uri::Uri()'],['../classedjx_1_1http_1_1Uri.html#ac688dde16108729b47231c1fae2d3087',1,'edjx::http::Uri::Uri(const std::string &amp;url)'],['../classedjx_1_1http_1_1Uri.html#a6be2bc08063039185d9c0027afe49726',1,'edjx::http::Uri::Uri(const char *url)'],['../classedjx_1_1http_1_1Uri.html#a840e2ef5151e140e3757598d8a0ed602',1,'edjx::http::Uri::Uri(const std::vector&lt; uint8_t &gt; &amp;url)']]],
  ['uriinvalid_6',['UriInvalid',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326a4bffabfc0f77d6180be3737da51e5c55',1,'edjx::error']]],
  ['uritoolarge_7',['UriTooLarge',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326a296e249ce46891da9149e158d51383bc',1,'edjx::error']]],
  ['utils_2ehpp_8',['utils.hpp',['../utils_8hpp.html',1,'']]]
];
