var searchData=
[
  ['uri_0',['uri',['../structedjx_1_1fetch_1_1HttpFetch.html#ac5f50f127886a372444e4253d5776190',1,'edjx::fetch::HttpFetch::uri()'],['../structedjx_1_1request_1_1HttpRequest.html#a88d35be3ce1a737ea0c1722dfb8128d0',1,'edjx::request::HttpRequest::uri()']]]
];
