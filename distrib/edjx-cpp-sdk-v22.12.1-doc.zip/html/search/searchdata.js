var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvw",
  1: "bcfhrsuw",
  2: "e",
  3: "efhklmrsu",
  4: "abcdefghioprstuw",
  5: "bdhimprsuv",
  6: "h",
  7: "hks",
  8: "cdeghimnoprstuw",
  9: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Pages"
};

