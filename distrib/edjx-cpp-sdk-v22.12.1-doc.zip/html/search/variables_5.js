var searchData=
[
  ['properties_0',['properties',['../structedjx_1_1storage_1_1FileAttributes.html#a4b2dbe91f696775afd78635900de5078',1,'edjx::storage::FileAttributes']]],
  ['properties_5fpresent_1',['properties_present',['../structedjx_1_1storage_1_1FileAttributes.html#a3589eefa09948c40c14757464df2ad45',1,'edjx::storage::FileAttributes']]]
];
