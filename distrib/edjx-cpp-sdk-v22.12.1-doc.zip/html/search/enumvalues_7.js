var searchData=
[
  ['none_0',['NONE',['../namespaceedjx_1_1http.html#af8b6065e534538695e8525d5795377f2ab50339a10e1de285ac99d4c3990b8693',1,'edjx::http']]],
  ['notfound_1',['NotFound',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65a38c300f4fc9ce8a77aad4a30de05cad8',1,'edjx::error']]]
];
