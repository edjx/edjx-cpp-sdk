var searchData=
[
  ['basestream_0',['BaseStream',['../classedjx_1_1stream_1_1BaseStream.html#a21d6735a2101fd6fa76e2c4dfc466a2a',1,'edjx::stream::BaseStream::BaseStream()'],['../classedjx_1_1stream_1_1BaseStream.html#a471f8b6ba2dac941740b537b9e67e71b',1,'edjx::stream::BaseStream::BaseStream(uint32_t sd)'],['../classedjx_1_1stream_1_1BaseStream.html',1,'edjx::stream::BaseStream']]],
  ['body_1',['body',['../structedjx_1_1fetch_1_1HttpFetch.html#ad645d3ad467cc9d2a47259489130c69b',1,'edjx::fetch::HttpFetch::body()'],['../structedjx_1_1response_1_1HttpResponse.html#a6aef2e812ff228a92196f8c78d848689',1,'edjx::response::HttpResponse::body()']]]
];
