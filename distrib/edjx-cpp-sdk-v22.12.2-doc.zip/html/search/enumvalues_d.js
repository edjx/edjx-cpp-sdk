var searchData=
[
  ['unauthorized_0',['UnAuthorized',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65ab2889fef041d52c0c3f04d6355e42a20',1,'edjx::error::UnAuthorized()'],['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467ab2889fef041d52c0c3f04d6355e42a20',1,'edjx::error::UnAuthorized()']]],
  ['unknown_1',['Unknown',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65a88183b946cc5f0e8c96b2e66e1c74a7e',1,'edjx::error::Unknown()'],['../namespaceedjx_1_1error.html#a0b0456030ab8f21099b6e255d0e15b07a88183b946cc5f0e8c96b2e66e1c74a7e',1,'edjx::error::Unknown()']]],
  ['unknownerror_2',['UnknownError',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326abfaef30f1c8011c5cefa38ae470fb7aa',1,'edjx::error']]],
  ['uriinvalid_3',['UriInvalid',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326a4bffabfc0f77d6180be3737da51e5c55',1,'edjx::error']]],
  ['uritoolarge_4',['UriTooLarge',['../namespaceedjx_1_1error.html#a4ed59b0ec94e84fcc3599d35ed21e326a296e249ce46891da9149e158d51383bc',1,'edjx::error']]]
];
