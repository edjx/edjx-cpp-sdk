var searchData=
[
  ['uri_0',['Uri',['../classedjx_1_1http_1_1Uri.html#a465f7c27d8fadb814a36014d8b48934d',1,'edjx::http::Uri::Uri()'],['../classedjx_1_1http_1_1Uri.html#ac688dde16108729b47231c1fae2d3087',1,'edjx::http::Uri::Uri(const std::string &amp;url)'],['../classedjx_1_1http_1_1Uri.html#a6be2bc08063039185d9c0027afe49726',1,'edjx::http::Uri::Uri(const char *url)'],['../classedjx_1_1http_1_1Uri.html#a840e2ef5151e140e3757598d8a0ed602',1,'edjx::http::Uri::Uri(const std::vector&lt; uint8_t &gt; &amp;url)']]]
];
