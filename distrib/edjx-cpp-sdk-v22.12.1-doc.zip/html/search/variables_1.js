var searchData=
[
  ['default_5fversion_0',['default_version',['../structedjx_1_1storage_1_1FileAttributes.html#ac9e17cfc76dcc90cd829f4af291ea6f7',1,'edjx::storage::FileAttributes']]],
  ['default_5fversion_5fpresent_1',['default_version_present',['../structedjx_1_1storage_1_1FileAttributes.html#aa756e8639bfa5edc07b7fe1f1c751ff0',1,'edjx::storage::FileAttributes']]]
];
