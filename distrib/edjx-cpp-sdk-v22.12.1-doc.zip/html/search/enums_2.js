var searchData=
[
  ['storageerror_0',['StorageError',['../namespaceedjx_1_1error.html#af8ad5986b548d740dc518a054b181467',1,'edjx::error']]],
  ['streamerror_1',['StreamError',['../namespaceedjx_1_1error.html#a0b0456030ab8f21099b6e255d0e15b07',1,'edjx::error']]]
];
