var searchData=
[
  ['httpheaders_0',['HttpHeaders',['../namespaceedjx_1_1http.html#aad38abada186f67224ae6c5d2c6e812b',1,'edjx::http']]],
  ['httpstatuscode_1',['HttpStatusCode',['../namespaceedjx_1_1http.html#a8354703109c421594021213cec5200cb',1,'edjx::http']]]
];
