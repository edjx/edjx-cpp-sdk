var searchData=
[
  ['error_0',['error',['../namespaceedjx_1_1logger.html#aecd81da38014e619d52025ead956ede1',1,'edjx::logger']]]
];
