var searchData=
[
  ['version_0',['version',['../structedjx_1_1fetch_1_1HttpFetch.html#a9d58f569581fc6ce4602a4e302a69548',1,'edjx::fetch::HttpFetch::version()'],['../structedjx_1_1request_1_1HttpRequest.html#a0d5e713a8d0127a0dfc0515afb6ef7c4',1,'edjx::request::HttpRequest::version()'],['../structedjx_1_1response_1_1HttpResponse.html#a51857f8a1170277ce9202b2db5214cf4',1,'edjx::response::HttpResponse::version()']]]
];
