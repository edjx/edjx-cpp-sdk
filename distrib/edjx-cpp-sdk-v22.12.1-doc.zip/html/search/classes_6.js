var searchData=
[
  ['uri_0',['Uri',['../classedjx_1_1http_1_1Uri.html',1,'edjx::http']]]
];
