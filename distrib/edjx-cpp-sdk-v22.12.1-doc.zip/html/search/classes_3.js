var searchData=
[
  ['httpfetch_0',['HttpFetch',['../structedjx_1_1fetch_1_1HttpFetch.html',1,'edjx::fetch']]],
  ['httprequest_1',['HttpRequest',['../structedjx_1_1request_1_1HttpRequest.html',1,'edjx::request']]],
  ['httpresponse_2',['HttpResponse',['../structedjx_1_1response_1_1HttpResponse.html',1,'edjx::response']]]
];
