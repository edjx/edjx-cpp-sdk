var searchData=
[
  ['debug_0',['debug',['../namespaceedjx_1_1logger.html#a8783b176c2cbc8fc6ac9c5703b12a8df',1,'edjx::logger']]]
];
