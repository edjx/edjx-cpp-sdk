var searchData=
[
  ['kverror_0',['KVError',['../namespaceedjx_1_1error.html#a8d0c35135109fef53bd4c60c24d76d65',1,'edjx::error']]]
];
