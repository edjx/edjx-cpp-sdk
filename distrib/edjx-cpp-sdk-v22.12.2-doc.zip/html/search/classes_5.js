var searchData=
[
  ['storageresponse_0',['StorageResponse',['../structedjx_1_1storage_1_1StorageResponse.html',1,'edjx::storage']]],
  ['storageresponsepending_1',['StorageResponsePending',['../structedjx_1_1storage_1_1StorageResponsePending.html',1,'edjx::storage']]]
];
