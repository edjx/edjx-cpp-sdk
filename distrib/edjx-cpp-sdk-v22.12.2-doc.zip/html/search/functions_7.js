var searchData=
[
  ['httpfetch_0',['HttpFetch',['../structedjx_1_1fetch_1_1HttpFetch.html#a6f69937fdbe5cd768f4c46802b694a6b',1,'edjx::fetch::HttpFetch']]],
  ['httprequest_1',['HttpRequest',['../structedjx_1_1request_1_1HttpRequest.html#a58849db731c6ea7404582c6973c3314d',1,'edjx::request::HttpRequest']]],
  ['httpresponse_2',['HttpResponse',['../structedjx_1_1response_1_1HttpResponse.html#a8debcdaf3956fb7a6ad7a87adbc9bad6',1,'edjx::response::HttpResponse::HttpResponse()'],['../structedjx_1_1response_1_1HttpResponse.html#a38761c924ea9159d9db350038366c493',1,'edjx::response::HttpResponse::HttpResponse(const std::string &amp;text)'],['../structedjx_1_1response_1_1HttpResponse.html#a98fe42e6441cc11091eae2f325935f71',1,'edjx::response::HttpResponse::HttpResponse(const std::vector&lt; uint8_t &gt; &amp;bytes)'],['../structedjx_1_1response_1_1HttpResponse.html#a5c932e39a6e436b62ae5cee09bfb70d5',1,'edjx::response::HttpResponse::HttpResponse(const uint8_t *mem, size_t size)']]]
];
